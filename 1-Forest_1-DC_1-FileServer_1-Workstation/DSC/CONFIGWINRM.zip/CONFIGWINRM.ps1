﻿Configuration CONFIGWINRM
{
   param
   (
        [String]$MaxEnvelopeSize
    )

    Node LocalHost
    {

        Script UpdateWinRMSettings
        {
            SetScript =
            {
                # Set WinRM MaxEnvelopeSize
                Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb -Value $MaxEnvelopeSize
            }
            GetScript =  { @{} }
            TestScript = { $false}
        }
    }
}