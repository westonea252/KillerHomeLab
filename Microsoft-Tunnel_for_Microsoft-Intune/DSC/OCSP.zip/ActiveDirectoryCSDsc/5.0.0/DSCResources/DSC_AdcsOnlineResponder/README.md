# Description

This resource can be used to install an ADCS Online Responder after the feature
has been installed on the server.
Using this DSC Resource to configure an ADCS Certificate Authority assumes that
the ```ADCS-Online-Responder``` feature has already been installed.
For more information on ADCS Online Responders, see [this article on TechNet](https://technet.microsoft.com/en-us/library/cc725958.aspx).
